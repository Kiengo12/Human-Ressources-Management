
<?php $__env->startSection('search'); ?>

<div class="row">
                    <!-- .col -->
                    <div class="col-md-12 col-lg-12 col-sm-12">
                        <div class="card white-box p-0">
                           
                                <?php if(count($recherche) ==0): ?>
                                 <div class="card-body">
                                    <h3 class="box-title mb-0">Aucun resultat  pour "<?php echo e($search); ?>"</h3>
                                </div>
                                 <?php endif; ?> 
                            
                               
                            
                                <?php if(count($recherche)!==0): ?> 
                                    <div class="card-body">
                                        <h3 class="box-title mb-0">Recherche pour "<?php echo e($search); ?>"</h3>
                                    </div>
                                <?php endif; ?>
                           
                        
                            <?php $__currentLoopData = $recherche; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recherches): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="comment-widgets">
                                <!-- Comment Row -->
                                <div class="d-flex flex-row comment-row p-3 mt-0">
                                    <div class="p-2"><img src="<?php echo e($recherches->photo_profile); ?>" alt="user" width="50" class="rounded-circle"></div>
                                    <div class="comment-text ps-2 ps-md-3 w-100">
                                        <h5 class="font-medium"><?php echo e($recherches->nom); ?></h5>
                                        <span class="mb-3 d-block"><?php echo e($recherches->resume); ?></span>
                                        <div class="comment-footer d-md-flex align-items-center">
                                        <a href="<?php echo e(route('recherche.show',$recherches->id)); ?>" class="btn btn-info ml-2"><i class="fa fa-solid fa-eye "></i></a>
                                             
                                             
                                            <div class="text-muted fs-2 ms-auto mt-2 mt-md-0"><?php echo e($recherches->date_naissance); ?></div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Comment Row -->
                                
                        
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.DashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\HumanRessources18\resources\views/recherche/search.blade.php ENDPATH**/ ?>