
<?php $__env->startSection('show'); ?>

<?php $__currentLoopData = $utilisateurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $utilisateur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
<div class="container-fluid">
         
                    
    <div class="row">
        <!-- Column -->
        <div class="col-lg-4 col-xlg-3 col-md-12">
            <div class="white-box">
                <div class="user-bg"> <img width="100%" alt="user" src="../images/profil.png">
                    <div class="overlay-box">
                        <div class="user-content">
                            <a href="javascript:void(0)"><img src="<?php echo e(Auth::user()->photo_profile); ?>"
                                    class="thumb-lg img-circle" alt="img"></a>
                            <h4 class="text-white mt-2"><?php echo e($utilisateur->nom); ?></h4>
                            <h5 class="text-white mt-2"><?php echo e($utilisateur->email); ?> </h5>
                        </div>
                    </div>
                </div>
                <div class="user-btm-box mt-5 d-md-flex">
                    <div class="col-md-12 col-sm-4 text-center">
                        <h3>Numero d'identification</h4>
                        <h1><?php echo e($utilisateur->id); ?></h1>
                    </div>
                    
                </div>
            </div>
        </div>
        <!-- Column -->
        
        <!-- Column -->
        <div class="col-lg-8 col-xlg-9 col-md-12">
            <div class="card">
                <div class="card-body">

                        <div class="form-group mb-4">
                            <label class="col-md-12 p-0">Noms et prenoms du representant legal</label>
                            <div class="col-md-12 border-bottom p-0">
                                <p><b><?php echo e($utilisateur->nom); ?></b></p>
                                </div>
                        </div>
                        <div class="form-group mb-4">
                            <label class="col-md-12 p-0">Noms et prenoms du representant juridique</label>
                            <div class="col-md-12 border-bottom p-0">
                                <p><b><?php echo e($utilisateur->prenom); ?></b></p>
                                </div>
                        </div>
                        <div class="form-group mb-4">
                            <label class="col-md-12 p-0">Email</label>
                            <div class="col-md-12 border-bottom p-0">
                                <p><b><?php echo e($utilisateur->email); ?></b></p>
                                </div>
                        </div>
                        <div class="form-group mb-4">
                            <label class="col-md-12 p-0">Domaine d'intervention</label>
                            <div class="col-md-12 border-bottom p-0">
                                <p><b><?php echo e($utilisateur->domaine_expertise); ?></b></p>
                                </div>
                        </div>
                        <div class="form-group mb-4">
                            <label class="col-md-12 p-0">Annees d'experiences</label>
                            <div class="col-md-12 border-bottom p-0">
                                <p><b><?php echo e($utilisateur->annee_experience); ?></b></p>
                                </div>
                        </div>
                        <div class="form-group mb-4">
                            <label class="col-md-12 p-0">References</label>
                            <div class="col-md-12 border-bottom p-0">
                                <p><b><?php echo e($utilisateur->references); ?></b></p>
                                </div>
                        </div>
                        <div class="form-group mb-4">
                            <label class="col-md-12 p-0">Pays</label>
                            <div class="col-md-12 border-bottom p-0">
                                <p><b><?php echo e($utilisateur->pays); ?></b></p>
                                </div>
                        </div>
                        <div class="form-group mb-4">
                            <label class="col-md-12 p-0">Ville</label>
                            <div class="col-md-12 border-bottom p-0">
                                <p><b><?php echo e($utilisateur->ville); ?></b></p>
                                </div>
                        </div>
                        <div class="form-group mb-4">
                            <label class="col-md-12 p-0">Annees d'experiences</label>
                            <div class="col-md-12 border-bottom p-0">
                                <p><b><?php echo e($utilisateur->annee_experience); ?></b></p>
                                </div>
                        </div>
                        <div class="form-group mb-4">
                            <label class="col-md-12 p-0">Breve descriptions des services proposes</label>
                            <div class="col-md-12 border-bottom p-0">
                                <p><b><?php echo e($utilisateur->resume); ?></b></p>
                                </div>
                        </div>
                        
                </div>
            </div>
        </div>
        <!-- Column -->
    </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.DashboardLayout1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\HumanRessources18\resources\views/showUser/prestataireShow.blade.php ENDPATH**/ ?>