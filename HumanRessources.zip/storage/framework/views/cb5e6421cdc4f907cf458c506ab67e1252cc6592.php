
<?php $__env->startSection('mission'); ?>


<div class="card white-box p-0">
    <div class="card-body">
        <h3 class="box-title mb-0">Les missions</h3>
    </div>
</div>    
 

  <div class="col-md-12">
    <div class="container">
      <div class="row hidden-md-up">
        <?php $__currentLoopData = $missions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
          <div class="card">
            <div class="card-block p-4">
              <h4 class="card-title"><b><?php echo e($mission->titre_mission); ?></b></h4>
              <p class="card-text p-y-1">Cout estimatif du projet:<?php echo e($mission->cout_projet); ?></p>
              <p class="card-text p-y-1">Objectifs du projet:<?php echo e($mission->objectif_projet); ?></p>
              <p class="card-text p-y-1">Description du projet:<?php echo e($mission->description_projet); ?></p>
              <p class="card-text p-y-1 text-muted">Domaines d'expertise sollicite: <?php echo e($mission->services_sollicites); ?></p>
              <p class="card-text p-y-1 text-muted">Date de debut: <?php echo e($mission->date_debut); ?></p>
              <p class="card-text p-y-1 text-muted">Date de fin: <?php echo e($mission->date_fin); ?></p>
              <a href="#" class="card-link btn btn-info"><i class="fa fa-eye"></i></a>
              <a href="#" class="card-link btn btn-danger"><i class="fa fa-solid fa-trash"></i></a>
            </div>
          </div>
        </div>
       
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
        
      </div>
    </div>
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\HumanRessources18\resources\views/adminMenu/missionMenu1.blade.php ENDPATH**/ ?>