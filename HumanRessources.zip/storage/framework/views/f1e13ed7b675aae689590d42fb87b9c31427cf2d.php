
<?php $__env->startSection('entrepriseMenu'); ?>

<div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-info alert-block">
                            
                            <strong><?php echo e($message); ?></strong>
                            <i class="fa-sharp fa-solid fa-circle-check"></i>
                        </div>

                <?php endif; ?>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box">
                            <h3 class="box-title">LES CANDIDATS POSTULANTS</h3>
                            <div class="table-responsive">
                                <table class="table text-nowrap">
                                    <thead>
                                        <tr>
                                            <th class="border-top-0">ID</th>
                                            <th class="border-top-0">Nom</th>
                                            <th class="border-top-0">Email</th>
                                            <th class="border-top-0">Domaine de formation</th>
                                            <th class="border-top-0">Annees d'experience</th>
                                            <th class="border-top-0">Numero de telephone</th>
                                            <th class="border-top-0">CV</th>
                                            <th class="border-top-0">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                       
                                        <?php $__currentLoopData = $postulants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postulant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($postulant->id); ?></td>
                                            <td><?php echo e($postulant->nom); ?></td>
                                            <td><?php echo e($postulant->email); ?></td>
                                            <td><?php echo e($postulant->domaine_expertise); ?></td>
                                            <td><?php echo e($postulant->annee_experience); ?></td>
                                            <td><?php echo e($postulant->phone); ?></td>
                                            
                                            <td><a href="<?php echo e($postulant->cv); ?>">tele</a></td>
                                            
                                            <td class="d-flex  pl-5">
                                                <a href="<?php echo e(route('postulant.show',$postulant->id)); ?>" class="btn btn-info ml-2"><i class="fa fa-solid fa-eye "></i></a>
                                                
                                                <button type="submit" class="btn btn-danger"  onclick="document.getElementById('modal-open').style.display='block'"><i class="fa fa-solid fa-trash"></i></button>
                                                
                                            
                                            </td>
                                            </td>
                                        </tr>
                                        <div class="modal" id="modal-open">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">La suppression est irreversible</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"  onclick="document.getElementById('modal-open').style.display='none'">
                                                    <span aria-hidden="true"></span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <p>Voulez vous supprimer ce candidat postulant?</p>
                                                </div>
                                                <div class="modal-footer">
                                                    <form action="<?php echo e(route('postulant.delete',$postulant->id)); ?>" method="POST">
                                                    <?php echo method_field('delete'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-danger">Supprimer</button>
                                                    </form>  
                                                    <button type="button" class="btn btn-info" onclick="document.getElementById('modal-open').style.display='none'" data-bs-dismiss="modal">Fermer</button>
                                                </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                
<?php $__env->stopSection(); ?>                
<?php echo $__env->make('layouts.DashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\HumanRessources18\resources\views/adminMenu/postulantMenu.blade.php ENDPATH**/ ?>